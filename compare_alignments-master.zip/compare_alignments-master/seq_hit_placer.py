import os
import argparse
import collections


parser = argparse.ArgumentParser()

parser.add_argument('-F', help='Filtered files directory', default='./filtered_files/')
parser.add_argument("-P", help='Directory to full PF00000 file', default='PF01699_full.txt')
parser.add_argument("-B", help='"Best version" alternative', action='store_true')
parser.add_argument("-L", help='Minimum length of best hits (Works only with -B option)', default=50)
parser.add_argument("-N", help='Number of best hits', default=100)

args = parser.parse_args()

path = args.F
list_of_files = os.listdir(path)

connections = {}
for i in list_of_files:
    file = open(path + i).read()
    file1 = file.split('#')
    file1 = [i1 for i1 in file1 if i1]
    for i1 in range(len(file1)):
        file1[i1] = file1[i1].split('\n')[2:]
        file1[i1] = [i2 for i2 in file1[i1] if i2]
    for i2 in range(len(file1)):
        # print(file1[i2])
        if len(file1[i2]) > 2:

            name = file1[i2][1].split(' ')[1]
            e_value = file1[i2][0].split(' ')[-1]
            sbjct_start_pos = None
            hit_length = None
            query_seq = ''
            for i3 in range(len(file1[i2]))[3:]:
                if 'Identities =' in file1[i2][i3]:
                    if sbjct_start_pos and hit_length:
                        # print(query_seq)
                        if file1[i2][0].split(' ')[0] in connections:
                            connections[file1[i2][0].split(' ')[0]].append([name, e_value, sbjct_start_pos, hit_length, query_seq])
                        else:
                            connections[file1[i2][0].split(' ')[0]] = [[name, e_value, sbjct_start_pos, hit_length, query_seq]]
                    hit_length = file1[i2][i3].split(' ')[3].split('/')[1]
                    sbjct_start_pos = [i4 for i4 in file1[i2][i3+3].split(' ') if i4][1]  # Remember to make it -1 for number of gaps.
                    query_seq = ''
                if 'Query' in file1[i2][i3]:
                    query_seq += [i4 for i4 in file1[i2][i3].split(' ') if i4][2]
            # print(file1[i2][0].split(' ')[0])  # NAMES OF SUBJECTS
            if file1[i2][0].split(' ')[0] in connections:
                connections[file1[i2][0].split(' ')[0]].append([name, e_value, sbjct_start_pos, hit_length, query_seq])
            else:
                connections[file1[i2][0].split(' ')[0]] = [[name, e_value, sbjct_start_pos, hit_length, query_seq]]


for i in connections:
    connections[i].sort(key=lambda i1: float(i1[1]))

### ALTERNATIVE ###
if args.B:
    best_how_many = args.N
    best_min_length = args.L
    convert = []
    for i in connections:
        for i1 in range(len(connections[i])):
            if len(connections[i][i1][-1]) >= best_min_length:
                temp = connections[i][i1]
                temp.append(i)
                convert.append(temp)

    convert.sort(key=lambda i2: float(i2[1]))

    connections0 = {}
    for i in range(len(convert[:best_how_many])):
        if convert[i][-1] in connections0:
            connections0[convert[i][-1]].append(convert[i][:-1])
        else:
            connections0[convert[i][-1]] = [convert[i][:-1]]

    connections = connections0

### END OF ALTERNATIVE ###

filler_lines = 3
first_filler = True
filler = '-'
file_name = args.P

state = False
found = ''
search_names = list(connections.keys())
num_lines = sum(1 for line in open(file_name))
with open(file_name) as original_file:
    for i in range(num_lines):
        line = original_file.readline().rstrip()
        if '>' in line:
            # print(line.lstrip('>').replace('/', '_').replace('-', '_'))
            if f"PF01699_{line.lstrip('>').replace('/', '_').replace('-', '_')}" in search_names:
                if found:
                    for i1 in connections[found]:
                        print(f'\n>{i1[0]} | {i1[1]}')
                        prefix = '-' * (int(i1[2])-1)
                        print(prefix, end='')
                        print(f'{i1[4]}', end='')
                        sufix = '-' * (int(found.split('_')[-1]) - int(found.split('_')[-2]) - int(i1[2]) - int(i1[3]) + 2)
                        print(sufix, end='')
                state = True
                if first_filler:
                    first_filler = False
                else:
                    print(f'\n>.')
                    print(filler)
                    for i5 in range(filler_lines - 1):
                        print(f'>.')
                        print(filler)
                print(f'\n>PF01699_{line.lstrip(">")}{"#" * (len(max(search_names, key=lambda i: len(i))) - len(line.lstrip(">")))}')
                found = f"PF01699_{line.lstrip('>').replace('/', '_').replace('-', '_')}"
            else:
                state = False
        else:
            if state:
                print(line, end='')
    print(f'\n>{i1[0]} | {i1[1]}')
    prefix = '-' * (int(i1[2]) - 1)
    print(prefix, end='')
    print(f'{i1[4]}', end='')
    sufix = '-' * (int(found.split('_')[-1]) - int(found.split('_')[-2]) - int(i1[2]) - int(i1[3]) + 2)
    print(sufix, end='')
