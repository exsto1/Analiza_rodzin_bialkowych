# compare_alignments

## Flags

Flag | Description | Default values
---|---|---
-F | Filtered files directory | ./filtered_files/
-P | Directory to full PF00000 file | PF01699_full.txt
-B | "Best version" alternative | False
-L | Minimum length of best hits (Works only with -B option) | 50
-N | Number of best hits | 100
