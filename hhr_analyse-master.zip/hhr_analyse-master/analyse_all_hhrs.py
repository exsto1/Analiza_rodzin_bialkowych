file = open('all_hhrs_biggest_1').readlines()
sectors = []
temp = []
for i in file:
    if 'Done!' in i:
        sectors.append(temp)
        temp = []
    else:
        temp.append(i)

for i0 in range(len(sectors)):
    state = False
    for i in range(len(sectors[i0])):
        if 'Query' in sectors[i0][i]:
            for i1 in range(len(sectors[i0][i])):
                if sectors[i0][i][i1] == 'P' and sectors[i0][i][i1+1] == 'F':
                    name = sectors[i0][i][i1] + sectors[i0][i][i1+1] + sectors[i0][i][i1+2] + sectors[i0][i][i1+3] + sectors[i0][i][i1+4] + sectors[i0][i][i1+5] + sectors[i0][i][i1+6]
        else:
            if ' PF' in sectors[i0][i] and 'gr' in sectors[i0][i]:
                if name not in sectors[i0][i]:
                    state = True
    if state:
        for i in range(len(sectors[i0])):
            print(sectors[i0][i])