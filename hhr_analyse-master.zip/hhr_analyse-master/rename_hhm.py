import os
import time

start = time.time()

directory = './hhms_3_biggest_families/'
lista_plikow = os.listdir(directory)

for i in lista_plikow:
    if '.hhm' in i:
        zapis = open(f'./3_biggest_families_profiles_renamed/{i}', 'w')
        new_name = i.rstrip('.hhm')
        file = open(f'{directory}{i}').readlines()
        for i1 in file:
            if 'NAME' in i1:
                zapis.write(f'NAME  {new_name}\n')
            else:
                zapis.write(i1)

print(time.time() - start)