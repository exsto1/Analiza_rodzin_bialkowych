# hhr_analyse

Scripts needed for analysing multiple .hhr files.    

## Usage
Before creating .hhr user can use script to rename .hhm sequences.    
After creating .hhr files use:
`cat *.hhr > all_hhrs`    
Then use generated file as input to second script.
