import argparse
import re

parser = argparse.ArgumentParser()

parser.add_argument("-F", help='File directory')
parser.add_argument("-Q", help='Query regex expression')
parser.add_argument("-S", help='Subject regex expression')
parser.add_argument("-E", help='E-value cut-off')

args = parser.parse_args()

query_pattern = re.compile(args.Q)
subject_pattern = re.compile(args.S)
print('Query: ' + args.Q)
print('Subject: ' + args.S)
print('##########################################')

file = open(args.F).readlines()
file = [i.rstrip() for i in file]

segments = []
temp = []
for i in range(len(file)):
    if 'Query= ' in file[i]:
        if temp:
            segments.append(temp)
            temp = [file[i]]
    else:
        temp.append(file[i])
segments.append(temp)


tempo = []
for i0 in segments:
    if re.search(query_pattern, i0[0]):
        values_list = []
        undersection = []
        for i in range(len(i0)):
            if '>' not in i0[i]:
                if re.search(subject_pattern, i0[i]) or re.search(query_pattern, i0[i]):
                    if 'Query=' not in i0[i]:
                        values_list.append(i0[i])
            if '>' in i0[i]:
                if tempo:
                    # for i1 in tempo:
                    #     print(i1)
                    undersection.append(tempo)
                    # print('------------')
                    tempo = [i0[i]]
            else:
                tempo.append(i0[i])
        undersection.append(tempo)

        if args.S == args.Q:
            undersection1 = undersection[1:]
        else:
            undersection1 = undersection

        for i in undersection1:
            state = False
            if re.search(subject_pattern, i[0]):
                for i1 in values_list:
                    if i[0].lstrip('> ') in i1:
                        check_e = i1.lstrip().split(' ')
                        check_e = [i for i in check_e if i]
                        if float(check_e[-1]) < float(args.E):
                            state = True
                            print("                                                             Score (Bits)  E Value")
                            print(i1.lstrip())
                if state:
                    print(i0[0], i0[2])
                    for i1 in i:
                        if 'Query= ' in i1:
                            break
                        print(i1)
                    print('####################################################################################')
