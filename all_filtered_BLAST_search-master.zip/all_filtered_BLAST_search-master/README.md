# all_filtered_BLAST_search

Skrypt do filtrowania plików blastp

## Flagi
Flagi | Opis
--- | ---
-F | File directory
-Q | Query regex expression
-S | Subject regex expression
-E | E-value cut-off

## Komendy
Komenda do wybrania wszystkich połączeń o e-value mniejszym niż 0.1:    
`python3 new1.py -F file/directory -Q PF -S PF -E 0.1`
