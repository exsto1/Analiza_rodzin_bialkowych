import argparse

def raw_extract(filename, output):
    iterations = 0
    round_number = 1

    num_lines = sum(1 for line in open(filename))

    zapis = open(output, 'w')
    with open(filename) as file_line:
        premature = False
        query_list = []
        temp_sektor = []
        sektor = False
        for i in range(num_lines):
            line = file_line.readline()
            if 'Query:' in line:
                zapis.write(f'>>>{line.split()[1]}\n')
                # query_list.append(line.split()[1])
            elif 'Round:' in line:
                round_number = line.split()[-1]
            elif 'Scores for complete sequences' in line:
                premature = True
                sektor = True
            elif '------ inclusion threshold ------' in line:
                sektor = False
            elif 'Domain annotation for each sequence' in line:
                if int(round_number) == int(iterations):
                    if not premature:
                        sektor_values = temp_sektor[3: -2]
                    else:
                        sektor_values = temp_sektor[3:]
                    premature = False
                    for i1 in range(len(sektor_values)):
                        if sektor_values[i1][0] == ' ':
                            print(sektor_values[i1])
                            evalue = sektor_values[i1].split()[0]
                            sequence = ' '.join(sektor_values[i1].split()[8:])
                        else:
                            evalue = sektor_values[i1].split()[1]
                            sequence = ' '.join(sektor_values[i1].split()[9:])
                        zapis.write(f'{sequence} +++ {evalue}\n')
                    round_number = 1
                sektor = False
                temp_sektor = []
            elif sektor:
                temp_sektor.append(line)
            elif 'maximum iterations set to:' in line:
                iterations = line.split()[-1]


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-F', help='File name from jackhmmer')
    parser.add_argument('-O', help='Output file name')

    args = parser.parse_args()
