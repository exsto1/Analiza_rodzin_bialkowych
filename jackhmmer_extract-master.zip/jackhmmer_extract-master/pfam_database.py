import raw_jackhmmer_extract as raw_ext

'''
Pfam database

Template:
NAME1_NAME2/000-000 DESCRIPTION1 DESCRIPTION2 PF00000.DESCRIPION3
'''


raw_ext.raw_extract('CL0057_clan_specific_files/jackhmmer_3_representatives_PF01402_group_0_4', 'pfam_temp_file_4')

filename = 'CL0057_clan_specific_files/pfam_temp_file'

num_lines = sum(1 for line in open(filename))

zapis = open('CL0057_clan_specific_files/pfam_output_4', 'w')
zapis2 = open('CL0057_clan_specific_files/pfam_links_4', 'w')
with open(filename) as file_line:
    temp_list = []
    for i in range(num_lines):
        line = file_line.readline()
        if '>>>' in line:
            if temp_list:
                families = []
                names = []
                evalues = []
                families_dict = {}
                for i1 in range(len(temp_list)):
                    evalue = temp_list[i1].split('+++')[-1]
                    evalues.append(evalue)
                    seq_full_name = temp_list[i1].split('+++')[0]
                    family = seq_full_name.split()[-1].split('.')[0]
                    families.append(family)
                    name = seq_full_name.split()[0]
                    names.append(name)
                for i1 in range(len(families)):
                    if families[i1] in families_dict:
                        families_dict[families[i1]] += 1
                    else:
                        families_dict[families[i1]] = 1
                for i1 in families_dict:
                    # print(f'%%%{i1} - {families_dict[i1]}/{len(families)}: {families_dict[i1]/len(families)*100}%')
                    zapis.write(f'%%%{i1} - {families_dict[i1]}/{len(families)}: {int(families_dict[i1]/len(families)*100)}%\n')
                    zapis2.write(f'%%%{i1} - {families_dict[i1]}/{len(families)}: {int(families_dict[i1] / len(families) * 100)}% - link: https://pfam.xfam.org/family/{i1}#tabview=tab1\n')
                    for i2 in range(len(families)):
                        if families[i2] == i1:
                            # print(f'{names[i2]} +++{evalues[i2].rstrip()}')
                            zapis.write(f'{names[i2]} +++{evalues[i2]}')
            # print(line.rstrip())
            zapis.write(line)
            zapis2.write(line)

            temp_list = []
        else:
            temp_list.append(line)
if temp_list:
    families = []
    names = []
    evalues = []
    families_dict = {}
    for i1 in range(len(temp_list)):
        evalue = temp_list[i1].split('+++')[-1]
        evalues.append(evalue)
        seq_full_name = temp_list[i1].split('+++')[0]
        family = seq_full_name.split()[-1].split('.')[0]
        families.append(family)
        name = seq_full_name.split()[0]
        names.append(name)
    for i1 in range(len(families)):
        if families[i1] in families_dict:
            families_dict[families[i1]] += 1
        else:
            families_dict[families[i1]] = 1
    for i1 in families_dict:
        # print(f'%%%{i1} - {families_dict[i1]}/{len(families)}: {families_dict[i1] / len(families) * 100}%')
        zapis.write(f'%%%{i1} - {families_dict[i1]}/{len(families)}: {int(families_dict[i1] / len(families) * 100)}%\n')
        zapis2.write(f'%%%{i1} - {families_dict[i1]}/{len(families)}: {int(families_dict[i1] / len(families) * 100)}% - link: https://pfam.xfam.org/family/{i1}#tabview=tab1\n')
        for i2 in range(len(families)):
            if families[i2] == i1:
                # print(f'{names[i2]} +++ {evalues[i2].rstrip()}')
                zapis.write(f'{names[i2]} +++ {evalues[i2]}')