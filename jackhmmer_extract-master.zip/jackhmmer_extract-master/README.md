# jackhmmer_extract

Scripts used to get data from JackHMMER savefiles.    
Returns files with found families percentage.

