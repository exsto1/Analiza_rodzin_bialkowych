filename = 'CL0057_clan_specific_files/jackhmmer_logfile'
iterations = 0
round_number = 1

num_lines = sum(1 for line in open(filename))

with open(filename) as file_line:
    query_list = []
    temp_sektor = []
    sektor = False
    for i in range(num_lines):
        line = file_line.readline()
        if 'Query:' in line:
            query_list.append(line.split()[1])
        elif 'Round:' in line:
            round_number = line.split()[-1]
        elif 'Scores for complete sequences (score includes all domains):' in line:
            sektor = True
        elif 'Domain annotation for each sequence (and alignments):' in line:
            if round_number == iterations:
                print(f'--------------------------------------{query_list[-1]}')
                sektor_values = temp_sektor[3: -2]
                for i1 in range(len(sektor_values)):
                    if sektor_values[i1][0] == ' ':
                        evalue = sektor_values[i1].split()[0]
                        sequence = sektor_values[i1].split()[8]
                        print(evalue, sequence)
                    else:
                        evalue = sektor_values[i1].split()[1]
                        sequence = sektor_values[i1].split()[9]
                        print(evalue, sequence)
                round_number = 1
            sektor = False
            temp_sektor = []
        elif sektor:
            temp_sektor.append(line)
        elif 'maximum iterations set to:' in line:
            iterations = line.split()[-1]
