# extracting_groups_from_CLANS_savefile

## Usage

Flag | Description 
--- | ---
-F | File directory

`python3 extracting_groups_from_CLANS_savefile -F path/to/CLANS/savefile`

Returns .fasta format files with name same as group name in CLANS.
