# figtree_fix

Run with:  
`python3 figtree_fix.py -K path_to_knot_pars_newick_file -S path_to_knot_support_newick_file`
