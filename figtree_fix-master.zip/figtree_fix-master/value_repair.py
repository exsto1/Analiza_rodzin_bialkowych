import re
import argparse

parser = argparse.ArgumentParser()

parser.add_argument("-K", help='Knot pars file')
parser.add_argument("-S", help='Support file')

args = parser.parse_args()


# ---------------------------------------------------------------------------------------------


supp_file = open(args.S)
supp_list = supp_file.readlines()
supp_file.close()

supp_line = supp_list[0].rstrip().lstrip()
supp_info = re.findall('(Inner.*?:.*?)[),]', supp_line)
supp_info = [i.split(':') for i in supp_info]

for i in range(len(supp_info)):
    if len(supp_info[i]) < 3:
        supp_info[i] = [supp_info[i][0], '0.00', supp_info[i][1]]


# ---------------------------------------------------------------------------------------------


pars_file = open(args.K)
pars_list = pars_file.readlines()
pars_file.close()
for i in pars_list:
    if 'Inner' in i:
        pars_line = i

try:
    pars_line = pars_line.lstrip().rstrip()
except NameError:
    print('Error')
    exit()

inners = re.findall('Inner.*?"]:', pars_line)
rest_of_the_text = re.split('Inner.*?"]:', pars_line)

new_inners = []
for i in range(len(inners)):
    for i1 in range(len(supp_info)):
        if supp_info[i1][0] == inners[i].split('"')[0]:
            temp = supp_info[i1][1] + '"]:'
            new_inners.append(temp)


# ---------------------------------------------------------------------------------------------


newline = rest_of_the_text[0]
for i in range(len(inners)):
    newline += new_inners[i]
    newline += rest_of_the_text[i + 1]

zapis = open('ver_final.newick', 'w')
for i in pars_list:
    if pars_line not in i:
        zapis.write(i)
    else:
        zapis.write(newline)
